<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MY SHOW</title>
    <link rel="stylesheet" href="style.css">
    <!---we had linked our css file----->
</head>

<body>
    <div class="full-page">
        <div class="navbar">
            <a href="homepage.php"><img src="myshow.jpg" style="height:45px"></a>
            <nav>
                <ul id='MenuItems'>
                    <li><a href='homepage.php'>HOME</a></li>
                    <li><a href='about.php'>ABOUT US</a></li>
                    <li><a href='help.php'>HELP</a></li>
                    <li><a href='loginpage.php'>LOGIN / REGISTER</a></li>
                </ul>
            </nav>
        </div>
        <div class="box">
            <form>
                <center>
                    <h1>
                        HELP!
                    </h1>
                    <hr>
                </center>
                <br>
                <div class="movie">
                    <img src="https://cdn.pixabay.com/photo/2016/06/03/07/58/social-media-1432937_960_720.jpg"
                        style="border-radius:50%">
                </div>
            </form>
        </div>
    </div>
</body>

</html>