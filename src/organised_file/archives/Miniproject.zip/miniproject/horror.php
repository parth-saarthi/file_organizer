<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>MY SHOW</title>
    <link rel="stylesheet" href="style.css">
    <!---we had linked our css file----->
</head>

<body>
    <div class="full-page">
        <div class="navbar">
            <a href="homepage.html"><img src="C:\Users\himan\Downloads\myshow.jpg" style="height:45px"></a>
            <nav>
                <ul id='MenuItems'>
                    <li><a href='homepage.html'>HOME</a></li>
                    <li><a href='about.html'>ABOUT US</a></li>
                    <li><a href='help.html'>HELP</a></li>
                    <li><a href='loginpage.html'>LOGIN / REGISTER</a></li>
                </ul>
            </nav>
        </div>



    </div>
</body>

</html>